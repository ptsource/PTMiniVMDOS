+++
title = "HX-Push Response Header (Deprecated)"
+++

The `HX-Push` header has been replaced by [`HX-Push-Url`](@/headers/hx-push-url.md)
