## Running The Website Locally

The htmx.org website is built with [Zola](https://www.getzola.org/).
To run the site, [install Zola](https://www.getzola.org/documentation/getting-started/installation/); then, from the root of the repository:

```
cd www
zola serve
```

The site should then be available at <http://localhost:1111>
